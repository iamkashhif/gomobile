import React from 'react'

const FranchiseEditor = () => {
  return (
    <div>FranchiseEditor</div>
  )
}

export default FranchiseEditor