import React from 'react'

const Active = () => {
  return (
    <div>Active</div>
  )
}

export default Active