
const Services = () => {
  return (
    <div className="text-black">Services</div>
  )
}

export default Services